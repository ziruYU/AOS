# Calendar-AOS-M2ASR

# Set Up:
1. Installez Nodejs et MongoDB
2. Démarrez MongoDB
3. Enterez le document de code source et utilisez 'npm start' pour démarrer le serveur Nodejs
4. Ouvrez le navigateur Web et accédez à  http: // localhost: 3000
