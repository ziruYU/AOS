$(document).ready(function() {
  /* Show search form. */
  $('#schevnt').on('click', searchEventhtml);
  /* Search button clicked */
  $('#eventform').on('click', '#btnSchEvent', srchEvent);
  /* Hide the search form */
  $('#eventform').on('click', '#btnSchCloseEvent', closeForm);
  /* Hide the search form */
  $('#eventform').on('click', '#btnTablCloseEvent', closeForm);
  /* If user want to seacrh again after search result shown to user */
  $('#eventform').on('click', '#btnSchAgain', searchEventhtml);

});

function searchEventhtml(e) {




  $.getJSON('/getevents', function( data )
  {
    e.preventDefault();
    var tableContent = '';
    if (data && data.length) {
      $.each(data, function(){
          tableContent += '<tr>';
          tableContent += '<td>' + this._id + '</td>';
          tableContent += '<td>' + this.startDate + '</td>';
          tableContent += '<td>' + this.endDate + '</td>';
          tableContent += '<td>' + this.startTime + '</td>';
          tableContent += '<td>' + this.endTime + '</td>';
          tableContent += '<td>' + this.description + '</td>';
          tableContent += '<td>' + this.place + '</td>';
          /* name attribute value is used to update or delete events */
        tableContent += '<td><button id="btnEditDel" class="btn btn-default btn-sm" name=' + this._id  + '><span class="glyphicon glyphicon-edit"></span>Edit/Del</button>' +
            '<button id="btnShareEvent" class="btn btn-success btn-sm" name=' + this._id  + '><span class="glyphicon glyphicon-share"></span> Share</button>'+
            '</td>';
          tableContent += '</tr>';
      });
      $('#eventform').html(''+

          '<form class="form" role="form">' +
          '<legend><strong>Search Events</strong>:</legend>' +
          '<div class="col-sm-6">' +
          '<div class="form-group">' +
          '<label for="startdate">Start Date:</label>' +
          '<input type="date" placeholder="YYYY-MM-DD" class="form-control" id="startDate" autofocus title="YYYY-MM-DD" />' +
          '</div> </div>' +
          '<div class="col-sm-6">' +
          '<div class="form-group">' +
          '<label for="enddate">End Date:</label>' +
          '<input type="date" placeholder="YYYY-MM-DD" class="form-control" id="endDate" title="YYYY-MM-DD" />' +
          '</div> </div> <br />' +
          '<div class="col-sm-5"></div>' +
          '<div>' +
          '<button id="btnSchEvent" class="btn btn-info"><span class="glyphicon glyphicon-search"></span> Search</button>' +
          '<button id="btnSchCloseEvent" class="btn btn-warning"><span class="glyphicon glyphicon-remove"></span> Close</button>' +
          '</div> <br />' +
          '</form>  <hr />'+

        '<h5><strong>Event List:</strong></h5>' +
        ' <div class="table-responsive">' +
        '   <table class="table table-striped table-bordered table-sm">' +
        '     <thead class="bg-success text-center">' +
        '       <tr><th>Event ID</th><th>Start Date</th><th>End Date</th><th>Start Time</th><th>End Time</th><th>Description</th><th>Location</th><th>Action</th></tr>' +
        '     </thead>' +
        '     <tbody>' + tableContent + '</tbody>' +
        '   </table>' +
        ' </div>' +

        '</div> <br />  <hr />'

      );
    }
  });
};

function srchEvent(e) {
  e.preventDefault();
  var d1 = $('#eventform input#startDate').val();
  var d2 = $('#eventform input#endDate').val();
  if ( d1 && !checkDateFormat(d1) ) {
    alert('Please enter a valid start date in YYYY-MM-DD format.');
    return;
  }
  if ( d2 && !checkDateFormat(d2) ) {
    alert('Please enter a valid end date in YYYY-MM-DD format.');
    return;
  }
  if ( d1 && d2 ) {
    if ( Date.parse(d1) > Date.parse(d2) ) {
      alert('Start date is later than end date. Please try again.');
      return;
    }
  }
  var srchConditions = {
    'startDate': d1,
    'endDate': d2
  }
  $.ajax({
    type: 'POST',
    data: srchConditions,
    url: '/searchevents',
    dataType: 'JSON'
  }).done(function( res, status ) {
    if (status) {
      $('#eventform input').val('');
      showEventsTable(res);
    } else {
      alert('Error: ' + res);
    }
  });
};

/* Show search result in table */
function showEventsTable(events) {
  var tableContent = '';
  if (events && events.length) {
    $.each(events, function(){
      tableContent += '<tr>';
      tableContent += '<td>' + this._id + '</td>';
      tableContent += '<td>' + this.startDate + '</td>';
      tableContent += '<td>' + this.endDate + '</td>';
      tableContent += '<td>' + this.startTime + '</td>';
      tableContent += '<td>' + this.endTime + '</td>';
      tableContent += '<td>' + this.description + '</td>';
      tableContent += '<td>' + this.place + '</td>';
      /* name attribute value is used to update or delete events */
      tableContent += '<td><button id="btnEditDel" class="btn btn-info btn-sm" name=' + this._id  + '>Edit/Del</button>' +
                      '<button id="btnShareEvent" class="btn btn-success btn-sm" name=' + this._id  + '><span class="glyphicon glyphicon-share"></span> Share</button>'+
                      '</td>';

      tableContent += '</tr>';
    });
    $('#eventform').html(''+
      '<h5><strong>Search Results:</strong></h5>' +
      '<div class="table-responsive">' +
        '<table class="table table-striped table-bordered table-sm">' +
          '<thead class="bg-success text-center">' +
            '<tr><th>Event ID</th><th>Start Date</th><th>End Date</th><th>Start Time</th><th>End Time</th><th>Description</th><th>Location</th><th>Action</th></tr>' +
          '</thead>' +
          '<tbody>' + tableContent + '</tbody>' +
        '</table>' +
      '</div> <br />' +
    '<div class="col-sm-4"></div>' +
    '<div>' +
        '<button id="btnSchAgain" class="btn btn-info"><span class="glyphicon glyphicon-search"></span> Search</button>' +
    '<button id="btnTablCloseEvent" class="btn btn-warning "><span class="glyphicon glyphicon-remove"></span> Close</button>' +
    '</div> <br /> <hr />'
    );
  }
  else {
    alert('No events found. Please try again.');
  }
};
